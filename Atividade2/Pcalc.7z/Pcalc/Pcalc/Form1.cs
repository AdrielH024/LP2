namespace Pcalc
{
    public partial class Form1 : Form
    {
        public Double numero1;
        public Double numero2;
        public Double numeroResultado;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            txtnum1.Clear();
            txtnum2.Clear();
            txtresult.Clear();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("voc� deseja sair", "Saida", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Close();
            }
        }

        private void txtnum1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtnum1.Text, out numero1))
            {
                MessageBox.Show("n�mero 1 inv�lido!");
                txtnum1.Focus();
            }
        }

        private void txtnum2_TextChanged(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtnum2.Text, out numero2))
            {
                MessageBox.Show("n�mero 2 inv�lido!");
                txtnum1.Focus();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            numeroResultado = numero1 + numero2;
            txtresult.Text = numeroResultado.ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            numeroResultado = numero1 - numero2;
            txtresult.Text = numeroResultado.ToString();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            numeroResultado = numero1 * numero2;
            txtresult.Text = numeroResultado.ToString();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (numero2 == 0)
            {
                MessageBox.Show("imposs�vel dividir por zero");
                txtnum2.Focus();
            }
            else
            {
                numeroResultado = numero1 / numero2;
                txtresult.Text = numeroResultado.ToString();
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
