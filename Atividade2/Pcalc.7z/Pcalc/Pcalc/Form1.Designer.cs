﻿namespace Pcalc
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtnum1 = new TextBox();
            txtnum2 = new TextBox();
            txtresult = new TextBox();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            button6 = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            SuspendLayout();
            // 
            // txtnum1
            // 
            txtnum1.Location = new Point(108, 12);
            txtnum1.Name = "txtnum1";
            txtnum1.Size = new Size(307, 31);
            txtnum1.TabIndex = 0;
            txtnum1.Validated += txtnum1_Validated;
            // 
            // txtnum2
            // 
            txtnum2.Location = new Point(108, 105);
            txtnum2.Name = "txtnum2";
            txtnum2.Size = new Size(307, 31);
            txtnum2.TabIndex = 1;
            txtnum2.TextChanged += txtnum2_TextChanged;
            // 
            // txtresult
            // 
            txtresult.Enabled = false;
            txtresult.Location = new Point(110, 190);
            txtresult.Name = "txtresult";
            txtresult.Size = new Size(307, 31);
            txtresult.TabIndex = 2;
            // 
            // button1
            // 
            button1.Location = new Point(549, 17);
            button1.Name = "button1";
            button1.Size = new Size(112, 34);
            button1.TabIndex = 3;
            button1.Text = "limpar";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(549, 102);
            button2.Name = "button2";
            button2.Size = new Size(112, 34);
            button2.TabIndex = 4;
            button2.Text = "sair";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.Location = new Point(108, 286);
            button3.Name = "button3";
            button3.Size = new Size(53, 34);
            button3.TabIndex = 5;
            button3.Text = "+";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.Location = new Point(180, 286);
            button4.Name = "button4";
            button4.Size = new Size(53, 34);
            button4.TabIndex = 6;
            button4.Text = "-";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // button5
            // 
            button5.Location = new Point(250, 286);
            button5.Name = "button5";
            button5.Size = new Size(53, 34);
            button5.TabIndex = 7;
            button5.Text = "*";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // button6
            // 
            button6.Location = new Point(321, 286);
            button6.Name = "button6";
            button6.Size = new Size(53, 34);
            button6.TabIndex = 8;
            button6.Text = "/";
            button6.UseVisualStyleBackColor = true;
            button6.Click += button6_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 192);
            label1.Name = "label1";
            label1.Size = new Size(86, 25);
            label1.TabIndex = 9;
            label1.Text = "resultado";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(16, 9);
            label2.Name = "label2";
            label2.Size = new Size(89, 25);
            label2.TabIndex = 10;
            label2.Text = "numero 1";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(9, 111);
            label3.Name = "label3";
            label3.Size = new Size(89, 25);
            label3.TabIndex = 11;
            label3.Text = "numero 2";
            label3.Click += label3_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(button6);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(txtresult);
            Controls.Add(txtnum2);
            Controls.Add(txtnum1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtnum1;
        private TextBox txtnum2;
        private TextBox txtresult;
        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button button6;
        private Label label1;
        private Label label2;
        private Label label3;
    }
}
