namespace PIMC
{
    public partial class Form1 : Form
    {
        double peso, altura, imc;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtAltura.Clear();
            txtIMC.Clear();
            txtPeso.Clear();
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            imc = peso / (altura * altura);
            imc = Math.Round(imc, 1);

            if (imc <= 18.5) {
                txtIMC.Text = imc + " - magreza - 0 obesidade grau zero";
            } else if (imc >= 18.5 || imc <= 24.9) {
                txtIMC.Text = imc + " - normal - obesidade grau zero";
            } else if (imc >= 25.0 || imc <= 29.4){
                txtIMC.Text = imc + " - sobrepeso - obesidade grau um";
            }
            else if (imc >= 30.0 || imc <= 39.9){
                txtIMC.Text = imc + " - obesidade - obesidade grau dois";
            }
            else{
                txtIMC.Text = imc + " - obesidade grave - obesidade grau tr�s";
            }

        }
        private void txtPeso_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtPeso_Validated(object sender, EventArgs e)
        {

            if (!double.TryParse(txtPeso.Text, out peso)||(peso<=0))
            {
                MessageBox.Show("peso inv�lido");
            }

        }

        private void txtAltura_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtAltura_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtAltura.Text, out altura))
            {
                MessageBox.Show("altura inv�lido");
            }
        }
    }
}
