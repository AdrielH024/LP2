﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace trabalho3
{
    public partial class Form1 : Form
    {
        double ladoA, ladoB, ladoC;
        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void TxtLadoB_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(TxtLadoB.Text, out ladoB))
            {
                MessageBox.Show("Lado B inválido");
            }
        }

        private void TxtLadoC_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(TxtLadoC.Text, out ladoC))
            {
                MessageBox.Show("Lado C inválido");
            }
        }

        private void BtnVerifica_Click(object sender, EventArgs e)
        {
            if (ladoA != 0 && ladoB != 0 && ladoC != 0)
            {
                if (ladoA < (ladoB + ladoC) && ladoB < (ladoA + ladoC) && ladoC < (ladoA + ladoC))
                {
                    if ((ladoA == ladoB && ladoC!= ladoA)^ (ladoB == ladoC && ladoC != ladoA) ^ (ladoA == ladoC && ladoC != ladoB))
                    {
                        MessageBox.Show("triangulo isóceles");
                    }
                    if (ladoA != ladoB && ladoB != ladoC && ladoA != ladoC)
                    {
                        MessageBox.Show("triangulo escaleno");
                    }
                    if(ladoA == ladoB && ladoB== ladoC && ladoC == ladoA)
                    {
                        MessageBox.Show("triangulo equilatero");
                    }
                }
                else
                {
                    MessageBox.Show("não é triangulo");
                }
            }
            else
            {
                MessageBox.Show("os lados devem ser diferentes de 0");
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void TxtLadoA_Validated(object sender, EventArgs e)
        {
            if(!double.TryParse(TxtLadoA.Text,out ladoA))
            {
                MessageBox.Show("Lado A inválido");
            }
        }
    }
}
   