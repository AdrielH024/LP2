﻿
namespace trabalho3
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.TxtLadoA = new System.Windows.Forms.TextBox();
            this.TxtLadoB = new System.Windows.Forms.TextBox();
            this.TxtLadoC = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.BtnVerifica = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // TxtLadoA
            // 
            this.TxtLadoA.Location = new System.Drawing.Point(181, 69);
            this.TxtLadoA.Name = "TxtLadoA";
            this.TxtLadoA.Size = new System.Drawing.Size(349, 20);
            this.TxtLadoA.TabIndex = 0;
            this.TxtLadoA.Validated += new System.EventHandler(this.TxtLadoA_Validated);
            // 
            // TxtLadoB
            // 
            this.TxtLadoB.Location = new System.Drawing.Point(181, 138);
            this.TxtLadoB.Name = "TxtLadoB";
            this.TxtLadoB.Size = new System.Drawing.Size(349, 20);
            this.TxtLadoB.TabIndex = 1;
            this.TxtLadoB.Validated += new System.EventHandler(this.TxtLadoB_Validated);
            // 
            // TxtLadoC
            // 
            this.TxtLadoC.Location = new System.Drawing.Point(181, 219);
            this.TxtLadoC.Name = "TxtLadoC";
            this.TxtLadoC.Size = new System.Drawing.Size(349, 20);
            this.TxtLadoC.TabIndex = 2;
            this.TxtLadoC.Validated += new System.EventHandler(this.TxtLadoC_Validated);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(51, 69);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "valor lado A";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(51, 138);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "valor lado B";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(51, 226);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "valor lado C";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // BtnVerifica
            // 
            this.BtnVerifica.Location = new System.Drawing.Point(235, 332);
            this.BtnVerifica.Name = "BtnVerifica";
            this.BtnVerifica.Size = new System.Drawing.Size(75, 23);
            this.BtnVerifica.TabIndex = 6;
            this.BtnVerifica.Text = "verificar";
            this.BtnVerifica.UseVisualStyleBackColor = true;
            this.BtnVerifica.Click += new System.EventHandler(this.BtnVerifica_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(565, 450);
            this.Controls.Add(this.BtnVerifica);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TxtLadoC);
            this.Controls.Add(this.TxtLadoB);
            this.Controls.Add(this.TxtLadoA);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox TxtLadoA;
        private System.Windows.Forms.TextBox TxtLadoB;
        private System.Windows.Forms.TextBox TxtLadoC;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button BtnVerifica;
    }
}

