﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Avaliação
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerifica_Click(object sender, EventArgs e)
        {
            float[,] valores = new float[2, 4];
            float[] somaMes = new float[2];
            float totalGeral = 0;
            
            for(int i=1; i <= 2; i++)
            {
                for(int j = 1; j <= 4; j++)
                {
                    var entrada = Interaction.InputBox($"Escreva o valor do mês {i} semana {j}", "", "", 23, 22);
                    if(entrada == "")
                    {
                        return;
                    }
                    if (float.TryParse(entrada, out valores[i - 1, j - 1]))
                    {
                        somaMes[i-1] += valores[i - 1, j - 1];
                        lbTotalVenda.Items.Add($" >> Total do mês {i} Semana {j}: {valores[i - 1, j - 1].ToString("F")}");
                    }
                    else
                    {
                        MessageBox.Show("Valor inválido");
                        j--;
                    }
                }
                totalGeral += somaMes[i - 1];
                lbTotalVenda.Items.Add($"Total do mês {i}: R$ {somaMes[i - 1].ToString("F")}");
                lbTotalVenda.Items.Add("--------------------");
            }
            lbTotalVenda.Items.Add($" >> Total Geral R$ {totalGeral.ToString("F")}");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lbTotalVenda.Items.Clear();
        }
    }
}
